plugin requirement:

    * php version latest 5.4
    * display error is off


add event in calendar requirement:
    set the visiblty event public
