<div class="wrap">
    <h2>New Calendar</h2>
    <div id="poststuff" style="direction: ltr;">
        <div id="post-body" class="metabox-holder columns-2">
            <div id="post-body-content">
		<p>New calendar registered successfully </p>
		<?php  echo '<a href="'.$url_redirect.'"><input class="button action" value="Back to List" type="button"></a>'; ?>
            </div>
        </div>
        <br class="clear">
    </div>
</div>
